from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
import csv, io, json
from app.database import get_db
from app.models import Case, AuditTrail
from app.schemas import CaseCreate, CaseResponse
from app.cases.services import assign_team

router = APIRouter()

@router.post("/upload")
async def upload_cases(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.endswith((".csv", ".json")):
        raise HTTPException(status_code=400, detail="Invalid file format")

    cases = []
    if file.filename.endswith(".csv"):
        content = await file.read()
        reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
        for row in reader:
            cases.append(dict(row))
    else:
        data = await file.read()
        cases = json.loads(data)

    for case_data in cases:
        assigned_team = assign_team(int(case_data["days_past_due"]))
        case = Case(**case_data, assigned_team=assigned_team)
        db.add(case)
    db.commit()
    return {"message": f"{len(cases)} cases uploaded successfully"}

@router.get("/")
def get_cases(db: Session = Depends(get_db)):
    return db.query(Case).all()

@router.patch("/{case_id}/update-status")
def update_case(case_id: str, new_status: str, db: Session = Depends(get_db)):
    case = db.query(Case).filter(Case.case_id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    audit = AuditTrail(case_id=case_id, old_status=case.status, new_status=new_status)
    case.status = new_status
    db.add(audit)
    db.commit()
    return {"message": f"Case {case_id} updated to {new_status}"}
