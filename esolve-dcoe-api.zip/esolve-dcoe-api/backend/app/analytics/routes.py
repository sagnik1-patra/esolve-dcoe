from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models import Case

router = APIRouter()

@router.get("/summary")
def get_summary(db: Session = Depends(get_db)):
    total_cases = db.query(func.count(Case.id)).scalar()
    by_status = db.query(Case.status, func.count(Case.id)).group_by(Case.status).all()
    by_team = db.query(Case.assigned_team, func.count(Case.id)).group_by(Case.assigned_team).all()
    return {
        "total_cases": total_cases,
        "cases_by_status": dict(by_status),
        "cases_by_team": dict(by_team),
        "avg_resolution_time": "3.5 days (mock)",
        "total_recovered": "₹1.2M (mock)"
    }
